'use strict';
module.exports = {
  // DEP Development
  //database : 'mongodb://localhost:27017/test',
  // DEP Deploy
  database : 'mongodb://abraham:1345@ds127531.mlab.com:27531/mean_tutorial',
  secret : 'yoursecret'
}